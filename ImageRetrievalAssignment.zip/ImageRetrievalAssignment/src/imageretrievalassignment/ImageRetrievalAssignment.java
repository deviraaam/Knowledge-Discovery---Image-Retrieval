/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imageretrievalassignment;
import ALI.*;
/**
 *
 * @author user
 */
public class ImageRetrievalAssignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        VectorLib vlib = new VectorLib();
        ImageLib imgsearch = new ImageLib();
        
        String srcdir="C:\\Users\\user\\Desktop\\corel_dataset\\Image DB/";
        String destdir="C:\\Users\\user\\Desktop\\corel_dataset\\Color DB/";
        String cvqdir="C:\\Users\\user\\Desktop\\corel_dataset\\cvq DB/";
        String srcfile, destfile;
        
        int[][][]rgb_colors=null;
        double[][]cvq=new double[1000][1000];
        double[][]images=new double[1000][1000];
        
        for(int i=0; i<1000; i++)
        {
            srcfile=srcdir+String.valueOf(i)+".jpg";
            rgb_colors=imgsearch.getRGB(srcfile);
            cvq[i]=imgsearch.ColorFeatureExtraction(rgb_colors);
        }
        vlib.saveDST(cvq,"cvq");
        
        for(int i=0; i<1000; i++)
        {
            srcfile=srcdir+String.valueOf(i)+".jpg";
            destfile=cvqdir+String.valueOf(i)+".jpg";
            imgsearch.RGB_to_CVQ_Image(srcfile, destfile, "jpg", 1000);
        }
        
        //Loading color Features
        cvq=vlib.readDST("cvq");
        for(int i=0; i<1000; i++)
        {
            destfile=destdir+"cvq"+String.valueOf(i);
            images[i]=vlib.copyArray(cvq[i]);
        }
        
        for(int i=0; i<1000; i++)
        {
            double[] query=vlib.copyArray(images[i]);
            double[][] hasil=imgsearch.SimilarityMeasurement("cosine", query, images);
            vlib.view(hasil);
        }
        
        
        
    }
    
}
